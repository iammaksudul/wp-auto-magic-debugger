<?php
function wp_debugger_run_scan() {
    $issues = [];
    
    // Check file permissions
    if (!is_writable(ABSPATH . 'wp-config.php')) {
        $issues[] = 'wp-config.php is not writable!';
    }
    
    // Check for missing .htaccess
    if (!file_exists(ABSPATH . '.htaccess')) {
        $issues[] = '.htaccess file is missing!';
    }

    return $issues;
}
