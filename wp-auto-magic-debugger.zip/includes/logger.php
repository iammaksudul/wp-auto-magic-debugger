<?php
function wp_debugger_log_issue($issue) {
    error_log('[WP Debugger] ' . $issue);
}
