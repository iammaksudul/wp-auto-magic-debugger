# WP Auto Magic Debugger

A powerful WordPress debugging plugin that scans and fixes common issues.

## Features
- Scans for file permission issues
- Detects missing .htaccess
- Auto-fixes common problems

## Installation
1. Upload the plugin to WordPress.
2. Activate it from the **Plugins** menu.
3. Run a scan from **WP Debugger** in the Admin panel.

## License
GPL-2.0+
