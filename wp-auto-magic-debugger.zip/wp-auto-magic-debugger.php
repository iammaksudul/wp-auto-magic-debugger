<?php
/**
 * Plugin Name: WP Auto Magic Debugger
 * Plugin URI: https://github.com/yourusername/wp-auto-magic-debugger
 * Description: An automated debugging tool for WordPress that scans and fixes common issues.
 * Version: 1.0
 * Author: Your Name
 * Author URI: https://yourwebsite.com
 * License: GPL2
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

// Include necessary files
include_once plugin_dir_path(__FILE__) . 'includes/scanner.php';
include_once plugin_dir_path(__FILE__) . 'includes/fixer.php';
include_once plugin_dir_path(__FILE__) . 'includes/logger.php';
include_once plugin_dir_path(__FILE__) . 'includes/settings.php';
include_once plugin_dir_path(__FILE__) . 'includes/cli.php';

// Admin menu setup
function wp_auto_magic_debugger_menu() {
    add_menu_page(
        'WP Auto Magic Debugger', 
        'WP Debugger', 
        'manage_options', 
        'wp-auto-magic-debugger', 
        'wp_auto_magic_debugger_dashboard', 
        'dashicons-shield',
        80
    );
}
add_action('admin_menu', 'wp_auto_magic_debugger_menu');

// Dashboard display function
function wp_auto_magic_debugger_dashboard() {
    echo '<div class="wrap">';
    echo '<h1>WP Auto Magic Debugger</h1>';
    echo '<p>Scan and fix common WordPress issues automatically.</p>';
    echo '<form method="post">';
    echo '<input type="submit" name="wp_debugger_scan" class="button button-primary" value="Run Debug Scan">';
    echo '</form>';
    
    if (isset($_POST['wp_debugger_scan'])) {
        wp_debugger_scan();
    }
    echo '</div>';
}

// Scan function (calls scanner.php)
function wp_debugger_scan() {
    $issues = wp_debugger_run_scan();
    if (empty($issues)) {
        echo '<p>No issues found!</p>';
    } else {
        echo '<p>Issues found:</p><ul>';
        foreach ($issues as $issue) {
            echo '<li>' . esc_html($issue) . '</li>';
        }
        echo '</ul>';
    }
}
